import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  turbopack: {
    // Без этого Next поднимается на уровень выше и находит чужой package-lock.json
    // в домашней папке, считая корнем проекта C:\Users\Acer.
    root: __dirname,
  },
  // Плавающий значок Next в углу перекрывал кнопку записи.
  devIndicators: false,
};

export default nextConfig;
