import Image from 'next/image';
import TeamShowcase from '@/components/ui/team-showcase';
import MobileNav from '@/components/site/mobile-nav';
import HorizonHero from '@/components/ui/horizon-hero-section';

/**
 * Кадры героя по порядку прокрутки: начало стрижки → макро-детали → рукопожатие.
 * 20 штук, сгенерированы в Higgsfield (Z Image), 1400×788, ~1.4 МБ на серию.
 *
 * Два приёма, на которых всё держится:
 *
 * 1. Середина сюжета снята макро, без лиц. Модель не принимает референсы,
 *    поэтому барбер от кадра к кадру был бы разным человеком — на руках,
 *    волосах и машинке это не видно. Лица только в первом и последнем кадре,
 *    и у них по одному варианту.
 *
 * 2. Внутри каждого макро-такта идут три кадра, сгенерированные ОДНИМ И ТЕМ ЖЕ
 *    промптом. Z Image повторяет композицию достаточно близко, и перетекание
 *    между такими кадрами читается как движение руки, а не как смена сцены.
 *    Разные промпты подряд давали бы слайд-шоу.
 *
 * Добавить кадр = положить файл в /public/hero и дописать путь сюда.
 * Соотношение сторон у всех кадров должно совпадать: размер плоскости
 * в сцене берётся с первого.
 */
const HERO_FRAMES = Array.from({ length: 20 }, (_, i) => `/hero/${String(i + 1).padStart(2, '0')}.jpg`);

const BOOKING_URL = 'https://zapis.kz/barbershop-kasym';
const INSTAGRAM_URL = 'https://instagram.com/kasym_barbershop';
const TWOGIS_URL = 'https://2gis.kz/petropavlovsk/firm/70000001041837300';

/** Рейтинг 2ГИС на 2026-09-15. Обновлять вместе с отзывами. */
const RATING = { score: '4.9', votes: 550, reviews: 318 };

/**
 * Отзывы с карточки 2ГИС, приведены дословно — правка чужого отзыва
 * исказила бы слова человека, который его написал. Опечатки авторов сохранены.
 */
const REVIEWS = [
  {
    name: 'Saden',
    text: 'Мастер Темирхан сделал свою работу очень аккуратно и красиво — всё понравилось! Видно, что мастер знает своё дело. Вежливый, внимательно выслушает и подскажет, как лучше подстричься, если вы не знаете, какую стрижку выбрать. Однозначно рекомендую этого мастера!',
  },
  {
    name: 'Рустем Сериков',
    text: 'Все на высшем уровне! Сервис и качество твёрдая 5. Администратор Акнур вообще умница! Приветливая, а главное дело свое знает отлично. Не смог по времени прийти, предупредил… Акнур чётко соориентировалась в этом вопросе, разобралась.',
  },
  {
    name: 'Ярослав Козловский',
    text: 'Хороший сервис отличный мастер все понравилось и качество выполняемой работы и цена одыкватная стрижкой доволен сегодня был в первые теперь буду ходить на постоянной основе',
  },
  {
    name: 'near die',
    text: 'Впервые пришел, решил сменить свою прическу, Нурсеит отличный барбер, подобрал за 30 минут то что надо, для первого шага сделал всё идеально!',
  },
  {
    name: 'Григорий Журавлёв',
    text: 'Молодой Барбер Темирхан, качественно подстриг, полностью оправдал и даже больше, с каждым приходом все лучше и лучше',
  },
];

const NAV_ITEMS = [
  { href: '#uslugi', label: 'Услуги' },
  { href: '#raboty', label: 'Работы' },
  { href: '#barbery', label: 'Барберы' },
  { href: '#otzyvy', label: 'Отзывы' },
  { href: '#filialy', label: 'Филиалы' },
  { href: '#kontakty', label: 'Контакты' },
];

const LOCATIONS = [
  { name: 'ДСР', address: 'ул. Жабаева, 106', phone: '+7 747 977 70 80', wa: 'https://wa.me/77479777080' },
  { name: 'Тайга', address: 'ул. Жабаева, 161', phone: '+7 778 839 45 84', wa: 'https://wa.me/77788394584' },
  { name: 'Шажимбаева', address: 'ул. Шажимбаева, 101', phone: '+7 707 927 77 80', wa: 'https://wa.me/77079277780' },
];

/**
 * Прайс с фотографий из историй Instagram. Цены в тенге.
 * Три уровня мастеров — так устроен их собственный прайс-лист.
 *
 * Расхождение между снимками: «Маска» у обычного мастера указана и как 1 000,
 * и как 1 500. Взято 1 000 — оно встречается на двух снимках из трёх.
 */
const PRICE_TIERS = ['Мастер', 'Топ-мастер', 'Касым'];

const PRICES = [
  { service: 'Стрижка', values: ['5 000', '6 000', '8 000'] },
  { service: 'Борода', values: ['3 500', '4 000', '5 000'] },
  { service: 'Стрижка + борода', values: ['—', '—', '13 000'] },
  { service: 'Тонировка', values: ['4 000', '5 000', '5 000'] },
  { service: 'Камуфляж бороды', values: ['3 000', '3 500', '4 000'] },
  { service: 'Маска', values: ['1 000', '1 500', '2 000'] },
  { service: 'Ваксинг, одна зона', values: ['1 000', '1 000', '1 500'] },
  { service: 'Hair Tattoo', values: ['1 000 / 2 000', '—', '—'] },
];

const PRICES_KIDS = [
  { service: 'Детская стрижка до 12 лет', value: '3 500' },
  { service: 'Подростки', value: '4 000' },
  { service: 'Студенты — скидка 10%', value: '4 500' },
  { service: 'Детская стрижка у Касыма', value: '5 000' },
];

const PRICES_BUNDLES = [
  { title: 'Комплекс 1', text: 'Стрижка + борода + тонировка', value: '16 000', was: '20 000' },
  { title: 'Комплекс 2', text: 'Стрижка + маска + ваксинг', value: '10 000' },
  { title: 'Уход', text: 'Чистка лица, ваксинг, массаж головы, маска', value: '10 000' },
];

/**
 * ВРЕМЕННО: кадры сгенерированы (Higgsfield, Z Image), это не работы Kasym.
 * Заменить на настоящие до запуска — галерея работ это прямое обещание
 * результата, и подменять его картинкой из модели нельзя.
 *
 * Все кадры без лица (затылок, профиль без глаз, макро): Z Image не принимает
 * референсы, поэтому в каждом кадре другой человек — на стрижке и бороде это
 * незаметно, на лице бросалось бы.
 */
const WORKS = [
  { src: '/works/01.jpg', alt: 'Скин-фейд со спины, чёткая линия перехода' },
  { src: '/works/02.jpg', alt: 'Подстриженная борода и чистая линия на шее' },
  { src: '/works/03.jpg', alt: 'Текстурный кроп с плавным переходом к затылку' },
  { src: '/works/04.jpg', alt: 'Низкий тейпер с ровной линией шеи' },
  { src: '/works/05.jpg', alt: 'Высокий скин-фейд у виска' },
  { src: '/works/06.jpg', alt: 'Короткая стрижка с чистым переходом на затылке' },
];

// Рейтинг из 2ГИС вместо числа подписчиков: подписчики не говорят
// ничего о качестве стрижки, оценка от 550 клиентов — говорит.
const STATS = [
  { n: RATING.score, label: 'рейтинг в 2ГИС', gold: true },
  { n: String(RATING.votes), label: 'оценок' },
  { n: '3', label: 'филиала' },
  { n: '2020', label: 'год основания' },
];

export default function Home() {
  return (
    <>
      <Header />
      <main id="top">
        <HorizonHero frames={HERO_FRAMES} />
        <Stats />
        <Services />
        <Works />
        <Barbers />
        <Reviews />
        <Locations />
        <BookingCta />
      </main>
      <Footer />
    </>
  );
}

/* ───────── Шапка ───────── */

function Header() {
  return (
    <header className="hdr fixed inset-x-0 top-0 z-50 backdrop-blur-[14px]">
      <div className="wrap flex h-[68px] items-center justify-between">
        <a href="#top" className="font-display text-[17px] font-semibold tracking-[0.28em] uppercase">
          Kasym
        </a>

        <nav className="hidden gap-9 text-[13px] tracking-[0.09em] text-muted-foreground uppercase md:flex">
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.href} href={item.href}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a href={BOOKING_URL} target="_blank" rel="noopener" className="btn btn-gold">
            Записаться
          </a>
          <MobileNav items={NAV_ITEMS} />
        </div>
      </div>
    </header>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a href={href} className="nav-link relative py-1 transition-colors duration-300 hover:text-foreground">
      {children}
    </a>
  );
}

/* ───────── Герой ───────── */

/* ───────── Фото-разделитель ───────── */

function Works() {
  return (
    <section id="raboty" className="sec border-t border-white/[0.08]">
      <div className="wrap">
        <SectionHead
          eyebrow="Работы"
          title={
            <>
              Видно
              <br />
              <span className="gold-text">по контуру</span>
            </>
          }
          lead="Переход, линия бороды, шея — то, на чём стрижка держится или разваливается."
        />

        <div className="rv-kids grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4">
          {WORKS.map((w) => (
            <div
              key={w.src}
              className="relative aspect-square overflow-hidden rounded-[14px] ring-1 ring-white/[0.08]"
            >
              <Image
                src={w.src}
                alt={w.alt}
                fill
                // .wrap обрезан на 1180px, поэтому шире этого карточка не растёт:
                // 33vw на широком мониторе заставил бы браузер тянуть кандидат вдвое крупнее нужного.
                sizes="(min-width: 1180px) 366px, (min-width: 768px) 33vw, 50vw"
                className="object-cover transition-transform duration-500 hover:scale-[1.04]"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Статы ───────── */

function Stats() {
  return (
    <div className="rv-kids grid grid-cols-2 gap-px border-y border-white/[0.08] bg-white/[0.08] md:grid-cols-4">
      {STATS.map((s) => (
        <div key={s.label} className="bg-background px-6 py-9">
          <div
            className={`font-display text-[clamp(30px,4.4vw,48px)] leading-none font-medium ${s.gold ? 'gold-text' : ''}`}
          >
            {s.n}
          </div>
          <div className="mt-2.5 text-xs tracking-[0.14em] text-muted-foreground/70 uppercase">{s.label}</div>
        </div>
      ))}
    </div>
  );
}

/* ───────── Услуги и цены ───────── */

function Services() {
  return (
    <section id="uslugi" className="sec">
      <div className="wrap">
        <SectionHead
          eyebrow="Услуги и цены"
          title={
            <>
              Прайс
              <br />
              <span className="gold-text">без сюрпризов</span>
            </>
          }
          lead="Цена зависит от уровня мастера. Все суммы в тенге."
        />

        {/* Таблица шире экрана на телефоне — прокручиваем её внутри себя,
            а не заставляем ездить всю страницу. */}
        <div className="rv -mx-6 overflow-x-auto px-6 md:mx-0 md:px-0">
          <table className="w-full min-w-[520px] border-collapse text-left">
            <thead>
              <tr className="border-b border-white/[0.08]">
                <th className="pb-4 text-[11px] font-medium tracking-[0.2em] text-muted-foreground/70 uppercase">
                  Услуга
                </th>
                {PRICE_TIERS.map((tier, i) => (
                  <th
                    key={tier}
                    className={`pb-4 text-right text-[11px] font-medium tracking-[0.2em] uppercase ${
                      i === PRICE_TIERS.length - 1 ? 'text-[var(--gold)]' : 'text-muted-foreground/70'
                    }`}
                  >
                    {tier}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PRICES.map((row) => (
                <tr key={row.service} className="border-b border-white/[0.05]">
                  <td className="py-4 text-[15px]">{row.service}</td>
                  {row.values.map((value, i) => (
                    <td
                      key={PRICE_TIERS[i]}
                      className={`py-4 text-right font-display text-[17px] tracking-[0.02em] ${
                        value === '—'
                          ? 'text-muted-foreground/40'
                          : i === row.values.length - 1
                            ? 'text-[var(--gold-soft)]'
                            : 'text-foreground/90'
                      }`}
                    >
                      {value}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Прайс на сайте всегда отстаёт от прайса на стене. Одна строка
            снимает спор у кассы — и заодно расхождения между снимками историй,
            по которым таблица собрана. */}
        <p className="rv mt-5 text-[13px] text-muted-foreground/60">
          Цены могут меняться — актуальные уточняйте при записи.
        </p>

        <div className="rv-kids mt-12 grid gap-4 md:grid-cols-2">
          <div className="rounded-[14px] border border-white/[0.08] bg-[#0e0e0e] p-7">
            <h3 className="mb-5 text-[11px] tracking-[0.2em] text-[var(--gold)] uppercase">Дети и студенты</h3>
            <dl className="flex flex-col gap-3">
              {PRICES_KIDS.map((row) => (
                <div key={row.service} className="flex items-baseline justify-between gap-4">
                  <dt className="text-[15px] text-muted-foreground">{row.service}</dt>
                  <dd className="font-display text-[17px] text-foreground/90">{row.value}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="rounded-[14px] border border-[var(--gold)]/30 bg-[#0e0e0e] p-7">
            <h3 className="mb-5 text-[11px] tracking-[0.2em] text-[var(--gold)] uppercase">Комплексы</h3>
            <dl className="flex flex-col gap-5">
              {PRICES_BUNDLES.map((row) => (
                <div key={row.title} className="flex items-baseline justify-between gap-4">
                  <div>
                    <dt className="text-[15px]">{row.title}</dt>
                    <p className="mt-1 text-[13px] text-muted-foreground">{row.text}</p>
                  </div>
                  <dd className="flex shrink-0 items-baseline gap-2">
                    {row.was && (
                      <span className="text-[13px] text-muted-foreground/50 line-through">{row.was}</span>
                    )}
                    <span className="font-display gold-text text-[19px]">{row.value}</span>
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────── Барберы ───────── */

function Barbers() {
  return (
    <section id="barbery" className="sec border-t border-white/[0.08]">
      <div className="wrap">
        <SectionHead
          eyebrow="Команда"
          title={
            <>
              Кто вас
              <br />
              <span className="gold-text">подстрижёт</span>
            </>
          }
          lead="Наведите на строку — увидите мастера. Напишите в WhatsApp филиала, чтобы записаться к нужному."
        />
        <div className="rv">
          <TeamShowcase />
        </div>
      </div>
    </section>
  );
}

/* ───────── Отзывы ───────── */

function Reviews() {
  return (
    <section id="otzyvy" className="sec border-t border-white/[0.08]">
      <div className="wrap">
        <div className="rv mb-13 flex flex-wrap items-end justify-between gap-8">
          <div>
            <div className="eyebrow">Отзывы</div>
            <h2 className="h2">
              Что говорят
              <br />
              <span className="gold-text">клиенты</span>
            </h2>
          </div>

          {/* Реальная оценка рядом с отобранными отзывами: иначе подборка
              только лучшего выглядела бы как обещание без основания. */}
          <a
            href={TWOGIS_URL}
            target="_blank"
            rel="noopener"
            className="flex items-baseline gap-3 transition-opacity duration-300 hover:opacity-80"
          >
            <span className="font-display gold-text text-[56px] leading-none font-medium">{RATING.score}</span>
            <span className="text-[13px] text-muted-foreground">
              {RATING.votes} оценок
              <br />
              {RATING.reviews} отзывов в 2ГИС
            </span>
          </a>
        </div>

        <div className="rv-kids grid gap-4 md:grid-cols-3">
          {REVIEWS.map((review) => (
            <figure
              key={review.name}
              className="flex flex-col gap-4 rounded-[14px] border border-white/[0.08] bg-[#0e0e0e] p-7 transition-colors duration-400 hover:border-[var(--gold)]/30"
            >
              <div className="text-[13px] tracking-[0.3em] text-[var(--gold)]" aria-label="Оценка 5 из 5">
                ★★★★★
              </div>
              <blockquote className="text-[14.5px] leading-relaxed text-muted-foreground">{review.text}</blockquote>
              <figcaption className="mt-auto text-[13px] tracking-[0.06em] text-foreground/80">
                {review.name}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Филиалы ───────── */

function Locations() {
  return (
    <section id="filialy" className="sec border-t border-white/[0.08]">
      <div className="wrap">
        <SectionHead
          eyebrow="Филиалы"
          title={
            <>
              Три адреса
              <br />в Петропавловске
            </>
          }
          lead="Пишите в WhatsApp нужного филиала — ответим и подберём время."
        />
        <div className="rv-kids grid gap-4 md:grid-cols-3">
          {LOCATIONS.map((l) => (
            <article
              key={l.name}
              className="flex flex-col gap-1.5 rounded-[14px] border border-white/[0.08] bg-[#0e0e0e] p-7 transition-colors duration-400 hover:border-[var(--gold)]/30 hover:bg-[#141414]"
            >
              <h3 className="font-display text-[26px] font-medium tracking-[0.04em] uppercase">{l.name}</h3>
              <p className="text-[14.5px] text-muted-foreground">{l.address}</p>
              <p className="text-[13px] tracking-[0.06em] text-muted-foreground/70">Ежедневно 10:00—20:00</p>
              <a href={l.wa} target="_blank" rel="noopener" className="btn btn-ghost mt-5 self-start">
                WhatsApp
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Онлайн-запись ───────── */

function BookingCta() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="rv rounded-[22px] border border-[var(--gold)]/30 bg-[#0e0e0e] bg-[radial-gradient(70%_120%_at_50%_0%,rgba(212,175,55,0.13),transparent_65%)] px-10 py-16 text-center">
          <div className="eyebrow justify-center">Онлайн-запись</div>
          <h2 className="h2">
            Выберите барбера
            <br />и <span className="gold-text">удобное время</span>
          </h2>
          <p className="mx-auto mt-4 mb-8 max-w-[56ch] text-[15.5px] text-muted-foreground">
            Занимает минуту. Подтверждение придёт сразу.
          </p>
          <a href={BOOKING_URL} target="_blank" rel="noopener" className="btn btn-gold">
            Записаться
          </a>
        </div>
      </div>
    </section>
  );
}

/* ───────── Подвал ───────── */

function Footer() {
  return (
    <footer id="kontakty" className="border-t border-white/[0.08] px-0 pt-14 pb-10">
      <div className="wrap">
        <div className="flex flex-wrap justify-between gap-9">
          <div className="flex flex-col gap-2.5 text-sm text-muted-foreground">
            <div className="ftr-title">Kasym Barbershop</div>
            <span>Петропавловск, Казахстан</span>
            <span>Ежедневно 10:00—20:00</span>
          </div>
          <div className="flex flex-col gap-2.5 text-sm text-muted-foreground">
            <div className="ftr-title">WhatsApp</div>
            {LOCATIONS.map((l) => (
              <a key={l.name} href={l.wa} target="_blank" rel="noopener" className="hover:text-[var(--gold-soft)]">
                {l.name} — {l.phone}
              </a>
            ))}
          </div>
          <div className="flex flex-col gap-2.5 text-sm text-muted-foreground">
            <div className="ftr-title">Ещё</div>
            <a href={BOOKING_URL} target="_blank" rel="noopener" className="hover:text-[var(--gold-soft)]">
              Онлайн-запись
            </a>
            <a href={INSTAGRAM_URL} target="_blank" rel="noopener" className="hover:text-[var(--gold-soft)]">
              Instagram @kasym_barbershop
            </a>
            <a href={TWOGIS_URL} target="_blank" rel="noopener" className="hover:text-[var(--gold-soft)]">
              Мы в 2ГИС — {RATING.score} из 5
            </a>
          </div>
        </div>
        <div className="mt-10 text-[12.5px] tracking-[0.04em] text-muted-foreground/70">
          {/* Год намеренно не выводим: страница статическая, дата зафиксировалась бы
              на моменте сборки и после Нового года показывала бы прошлый год. */}
          © Kasym Barbershop
        </div>
      </div>
    </footer>
  );
}

/* ───────── Общий заголовок секции ───────── */

function SectionHead({
  eyebrow,
  title,
  lead,
}: {
  eyebrow: string;
  title: React.ReactNode;
  lead: string;
}) {
  return (
    <div className="rv mb-13">
      <div className="eyebrow">{eyebrow}</div>
      <h2 className="h2">{title}</h2>
      <p className="mt-4 max-w-[56ch] text-[15.5px] text-muted-foreground">{lead}</p>
    </div>
  );
}
