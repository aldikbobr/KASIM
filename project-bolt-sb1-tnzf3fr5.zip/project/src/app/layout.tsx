import type { Metadata } from 'next';
import { Oswald, Golos_Text } from 'next/font/google';
import './globals.css';

const oswald = Oswald({
  subsets: ['cyrillic', 'latin'],
  variable: '--font-oswald',
  display: 'swap',
});

const golos = Golos_Text({
  subsets: ['cyrillic', 'latin'],
  variable: '--font-golos',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'KASYM — барбершоп №1 в Петропавловске',
  description:
    'Барбершоп KASYM в Петропавловске. Три филиала, барберы-чемпионы, онлайн-запись. Ежедневно 10:00—20:00.',
  openGraph: {
    title: 'KASYM — барбершоп №1 в Петропавловске',
    description: 'Три филиала, барберы-чемпионы, онлайн-запись. Ежедневно 10:00—20:00.',
    locale: 'ru_KZ',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${oswald.variable} ${golos.variable}`}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
