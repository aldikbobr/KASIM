'use client';

import { useEffect, useState } from 'react';

export interface NavItem {
  href: string;
  label: string;
}

export default function MobileNav({ items }: { items: NavItem[] }) {
  const [open, setOpen] = useState(false);

  // Закрытие по Escape + блокировка прокрутки страницы под открытым меню
  useEffect(() => {
    if (!open) return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', onKeyDown);

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  return (
    <div className="md:hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Закрыть меню' : 'Открыть меню'}
        aria-expanded={open}
        aria-controls="mobile-nav"
        className="flex h-11 w-11 items-center justify-center"
      >
        <span className={`burger-icon ${open ? 'is-open' : ''}`} />
      </button>

      {open && (
        <nav id="mobile-nav" className="mob-panel">
          {items.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setOpen(false)} className="mob-link">
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </div>
  );
}
