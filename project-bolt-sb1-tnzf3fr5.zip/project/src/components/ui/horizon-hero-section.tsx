'use client';

import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import styles from './horizon-hero-section.module.css';

/* ──────────────────────────────────────────────────────────────
   Адаптация компонента horizon-hero-section (21st.dev).
   От оригинала осталась только механика прокрутки: звёздное поле,
   небула и атмосферная сфера убраны — космос не к месту в барбершопе.
   Сцена теперь минимальная: чёрный фон, последовательность кадров
   стрижки с кросс-фейдом и медленный наезд камеры.

   Вступительная анимация сделана на CSS, а не на GSAP: связка
   gsap.from + таймлайн + двойной прогон эффектов в StrictMode
   оставляла подзаголовок и кнопки навсегда в стартовом состоянии.
   У CSS-анимации нет этого класса отказов, и при любом сбое
   контент остаётся видимым.
   ────────────────────────────────────────────────────────────── */

const TOTAL_SECTIONS = 2; // экранов прокрутки сверх первого

interface StageAction {
  label: string;
  href: string;
  variant: 'gold' | 'ghost';
  external?: boolean;
}

interface Stage {
  eyebrow: string;
  title: string;
  lines: [string, string];
  actions?: StageAction[];
}

const BOOKING_URL = 'https://zapis.kz/barbershop-kasym';

const STAGES: Stage[] = [
  {
    eyebrow: 'Барбершоп №1 · Петропавловск',
    title: 'KASYM',
    lines: ['Три филиала, барберы-чемпионы,', 'ежедневно с 10:00 до 20:00'],
    actions: [
      { label: 'Записаться', href: BOOKING_URL, variant: 'gold', external: true },
      { label: 'Филиалы', href: '#filialy', variant: 'ghost' },
    ],
  },
  {
    eyebrow: 'Мастера',
    title: 'Чемпионы',
    lines: ['Форма под тип волос и черты лица.', 'С укладкой и разбором, как повторить дома'],
  },
  {
    eyebrow: 'Как попасть',
    title: 'Запись',
    lines: ['Онлайн занимает минуту.', 'Или напишите в WhatsApp своего филиала'],
    actions: [
      { label: 'Записаться', href: BOOKING_URL, variant: 'gold', external: true },
      { label: 'Услуги', href: '#uslugi', variant: 'ghost' },
    ],
  },
];

interface PhotoLayer {
  mesh: THREE.Mesh;
  material: THREE.ShaderMaterial;
  baseX: number;
}

/** Доля прокрутки, за которую проигрывается вся последовательность кадров.
 *  Камера больше не пролетает сквозь фото, поэтому серия тянется до конца:
 *  последний кадр (рукопожатие) оказывается за блоком записи. */
const SEQUENCE_END = 0.97;

interface ThreeRefs {
  scene: THREE.Scene | null;
  camera: THREE.PerspectiveCamera | null;
  renderer: THREE.WebGLRenderer | null;
  composer: EffectComposer | null;
  photoLayers: PhotoLayer[];
  frames: THREE.Texture[];
  animationId: number | null;
  target: { x: number; y: number; z: number };
  running: boolean;
}

/** Положения камеры для каждого экрана прокрутки.
 *  Медленный наезд на фото, без пролёта сквозь него: плоскость стоит на z = -70,
 *  камера до неё не доходит и кадр остаётся в поле зрения всю прокрутку. */
const CAMERA_PATH = [
  { x: 0, y: 8, z: 190 },
  { x: 0, y: 10, z: 142 },
  { x: 0, y: 12, z: 96 },
];

/**
 * Кадры проигрываются по мере прокрутки с кросс-фейдом между соседними.
 * Чтобы добавить кадр — просто положить файл в /public и дописать путь в массив.
 * Все кадры должны быть одного соотношения сторон: размер плоскости берётся с первого.
 */
export const Component = ({ frames = ['/hero/01.jpg'] }: { frames?: string[] }) => {
  const containerRef = useRef<HTMLElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const progressFillRef = useRef<HTMLDivElement | null>(null);

  const smoothCameraPos = useRef({ ...CAMERA_PATH[0] });

  const [currentSection, setCurrentSection] = useState(0);
  const [ready, setReady] = useState(false);
  const [webglFailed, setWebglFailed] = useState(false);

  const threeRefs = useRef<ThreeRefs>({
    scene: null,
    camera: null,
    renderer: null,
    composer: null,
    photoLayers: [],
    frames: [],
    animationId: null,
    target: { ...CAMERA_PATH[0] },
    running: true,
  });

  /* ───────── Инициализация Three.js ───────── */
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    // Уважаем системную настройку «меньше движения» — тяжёлую сцену не поднимаем вовсе
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const refs = threeRefs.current;
    const isMobile = window.innerWidth < 768;
    let disposed = false;

    /** Одна плоскость с фото. Слоёв-дымки больше нет: без звёзд на чёрном фоне
     *  увеличенные копии кадра читались бы не как глубина, а как двоение. */
    const createSequence = (textures: THREE.Texture[]) => {
      const image = textures[0].image as { width: number; height: number };
      const aspect = image.width / image.height;

      const layers = [{ z: -70, width: 620, opacity: 1, additive: false }];

      layers.forEach((layer) => {
        const geometry = new THREE.PlaneGeometry(layer.width, layer.width / aspect);
        const material = new THREE.ShaderMaterial({
          uniforms: {
            // Два слота под соседние кадры: шейдер смешивает их по blend.
            // Одна плоскость вместо N — не плодим draw call на каждый кадр.
            mapA: { value: textures[0] },
            mapB: { value: textures[Math.min(1, textures.length - 1)] },
            blend: { value: 0 },
            opacity: { value: layer.opacity },
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D mapA;
            uniform sampler2D mapB;
            uniform float blend;
            uniform float opacity;
            varying vec2 vUv;

            void main() {
              vec4 tex = mix(texture2D(mapA, vUv), texture2D(mapB, vUv), blend);

              // Мягкое затухание к краям, чтобы кадр не висел резким
              // прямоугольником на чёрном, а уходил в фон.
              vec2 d = abs(vUv - 0.5) * 2.0;
              float edge = (1.0 - smoothstep(0.55, 1.0, d.x)) * (1.0 - smoothstep(0.45, 1.0, d.y));

              gl_FragColor = vec4(tex.rgb, tex.a * opacity * edge);
            }
          `,
          transparent: true,
          depthWrite: false,
          blending: layer.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
        });

        // На узком экране в кадр попадает лишь центральная полоса фото, где затылок
        // клиента. Сдвигаем плоскость влево, чтобы в неё вошёл барбер справа.
        const baseX = isMobile ? -layer.width * 0.22 : 0;

        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(baseX, 6, layer.z);
        mesh.renderOrder = layer.z; // дальние слои рисуются первыми
        refs.scene!.add(mesh);
        refs.photoLayers.push({ mesh, material, baseX });
      });
    };

    const animate = () => {
      if (disposed) return;
      refs.animationId = requestAnimationFrame(animate);

      // Вне видимости героя рисовать нечего — экономим батарею на длинной странице
      if (!refs.running) return;

      const time = Date.now() * 0.001;

      if (refs.camera) {
        const smoothing = 0.06;
        smoothCameraPos.current.x += (refs.target.x - smoothCameraPos.current.x) * smoothing;
        smoothCameraPos.current.y += (refs.target.y - smoothCameraPos.current.y) * smoothing;
        smoothCameraPos.current.z += (refs.target.z - smoothCameraPos.current.z) * smoothing;

        refs.camera.position.x = smoothCameraPos.current.x + Math.sin(time * 0.1) * 2;
        refs.camera.position.y = smoothCameraPos.current.y + Math.cos(time * 0.15) * 1;
        refs.camera.position.z = smoothCameraPos.current.z;
        refs.camera.lookAt(0, 8, -600);
      }

      // Едва заметное дыхание кадра, чтобы картинка не выглядела замороженной
      refs.photoLayers.forEach((layer) => {
        layer.mesh.position.x = layer.baseX + Math.sin(time * 0.1) * 1.5;
        layer.mesh.position.y = 6 + Math.cos(time * 0.15) * 0.8;
      });

      refs.composer?.render();
    };

    try {
      refs.scene = new THREE.Scene();

      refs.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 2000);
      refs.camera.position.set(CAMERA_PATH[0].x, CAMERA_PATH[0].y, CAMERA_PATH[0].z);

      refs.renderer = new THREE.WebGLRenderer({ canvas, antialias: !isMobile, alpha: true });
      refs.renderer.setSize(window.innerWidth, window.innerHeight);
      refs.renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1.5 : 2));
      refs.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      refs.renderer.toneMappingExposure = 0.5;

      refs.composer = new EffectComposer(refs.renderer);
      refs.composer.addPass(new RenderPass(refs.scene, refs.camera));
      // Высокий порог: свечение достаётся только ярким бликам на фото —
      // лампам и хрому машинки. Это плёночный отсвет, а не общая дымка.
      refs.composer.addPass(
        new UnrealBloomPass(
          new THREE.Vector2(window.innerWidth, window.innerHeight),
          isMobile ? 0.2 : 0.3,
          0.5,
          0.96,
        ),
      );

      animate();
    } catch (error) {
      // Устройство без WebGL — остаёмся на статичном фото
      console.error('WebGL недоступен, герой показан статичным фото:', error);
      setWebglFailed(true);
      return;
    }

    // Кадры грузятся асинхронно и все сразу: статичный фон снимаем только когда
    // готова вся последовательность, иначе на прокрутке кадр упрётся в пустоту.
    const loader = new THREE.TextureLoader();
    const loadFrame = (src: string) =>
      new Promise<THREE.Texture | null>((resolve) => {
        loader.load(
          src,
          (texture) => {
            texture.colorSpace = THREE.SRGBColorSpace;
            resolve(texture);
          },
          undefined,
          () => resolve(null), // битый путь не должен обрушить весь герой
        );
      });

    Promise.all(frames.map(loadFrame)).then((loaded) => {
      const ok = loaded.filter((texture): texture is THREE.Texture => texture !== null);

      if (disposed) {
        ok.forEach((texture) => texture.dispose());
        return;
      }

      if (ok.length > 0) {
        refs.frames = ok;
        createSequence(ok);
        // Кадры догрузились уже после первого расчёта прокрутки. Если страницу
        // открыли прокрученной, без этого нужный кадр появится только после
        // первого движения колеса.
        window.dispatchEvent(new Event('scroll'));
      }
      setReady(true);
    });

    const handleResize = () => {
      if (!refs.camera || !refs.renderer || !refs.composer) return;
      refs.camera.aspect = window.innerWidth / window.innerHeight;
      refs.camera.updateProjectionMatrix();
      refs.renderer.setSize(window.innerWidth, window.innerHeight);
      refs.composer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    const observer = new IntersectionObserver(
      ([entry]) => {
        refs.running = entry.isIntersecting;
      },
      { threshold: 0 },
    );
    observer.observe(container);

    return () => {
      disposed = true;
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      if (refs.animationId) cancelAnimationFrame(refs.animationId);

      refs.photoLayers.forEach((layer) => {
        layer.mesh.geometry.dispose();
        layer.material.dispose();
      });
      refs.photoLayers = [];

      refs.frames.forEach((texture) => texture.dispose());
      refs.frames = [];
      refs.composer?.dispose();
      refs.renderer?.dispose();
      refs.scene = null;
    };
    // Ключом берём склеенные пути, а не сам массив: у литерала в пропсах новая
    // ссылка на каждый рендер, и сцена пересобиралась бы с нуля каждый раз.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frames.join('|')]);

  /* ───────── Прокрутка ─────────
     Прогресс считается по собственной высоте секции, а не по всему документу:
     иначе камера продолжала бы ехать, пока листаешь услуги и футер. */
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const refs = threeRefs.current;
    let frame = 0;

    const update = () => {
      frame = 0;
      const span = container.offsetHeight - window.innerHeight;
      const scrolled = Math.min(Math.max(-container.getBoundingClientRect().top, 0), Math.max(span, 0));
      const progress = span > 0 ? scrolled / span : 0;

      // Полосу прогресса двигаем напрямую: setState на каждый кадр прокрутки
      // перерисовывал бы всё дерево героя.
      if (progressFillRef.current) {
        progressFillRef.current.style.transform = `scaleX(${progress})`;
      }

      const section = Math.min(Math.floor(progress * TOTAL_SECTIONS), TOTAL_SECTIONS);
      setCurrentSection((prev) => (prev === section ? prev : section));

      const sectionProgress = (progress * TOTAL_SECTIONS) % 1;
      const from = CAMERA_PATH[section] ?? CAMERA_PATH[0];
      const to = CAMERA_PATH[section + 1] ?? from;

      refs.target.x = from.x + (to.x - from.x) * sectionProgress;
      refs.target.y = from.y + (to.y - from.y) * sectionProgress;
      refs.target.z = from.z + (to.z - from.z) * sectionProgress;

      // Фото гасим, когда камера сквозь него пролетает
      // Какие два кадра сейчас на экране и насколько второй проявлен
      const count = refs.frames.length;
      let indexA = 0;
      let indexB = 0;
      let blend = 0;

      if (count > 1) {
        const position = (Math.min(progress, SEQUENCE_END) / SEQUENCE_END) * (count - 1);
        indexA = Math.min(Math.floor(position), count - 2);
        indexB = indexA + 1;
        blend = position - indexA;
      }

      if (count > 1) {
        refs.photoLayers.forEach((layer) => {
          layer.material.uniforms.mapA.value = refs.frames[indexA];
          layer.material.uniforms.mapB.value = refs.frames[indexB];
          layer.material.uniforms.blend.value = blend;
        });
      }
    };

    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    update();

    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  const splitTitle = (text: string) =>
    text.split('').map((char, i) => (
      <span key={`${char}-${i}`} className={styles.titleChar} style={{ animationDelay: `${i * 0.06}s` }}>
        {char}
      </span>
    ));

  return (
    <section
      ref={containerRef}
      className={`${styles.heroContainer} ${webglFailed ? styles.heroStatic : ''}`}
      style={{ '--hero-photo': `url(${frames[0]})` } as React.CSSProperties}
    >
      <div className={styles.heroSticky}>
        {!webglFailed && <canvas ref={canvasRef} className={styles.heroCanvas} />}
        {/* Держим фото под сценой, пока WebGL не отрисовал первый кадр */}
        {!ready && <div className={styles.heroFallback} />}

        <div className={styles.heroScrim} />

        {!webglFailed && (
          <div className={styles.scrollProgress}>
            <div className={styles.scrollText}>Листайте</div>
            <div className={styles.progressTrack}>
              <div ref={progressFillRef} className={styles.progressFill} style={{ transform: 'scaleX(0)' }} />
            </div>
            {/* Счётчик с единицы: «00 / 02» читается как ошибка */}
            <div className={styles.sectionCounter}>
              {String(currentSection + 1).padStart(2, '0')} / {String(TOTAL_SECTIONS + 1).padStart(2, '0')}
            </div>
          </div>
        )}
      </div>

      <div className={styles.heroStages}>
        {STAGES.map((stage, index) => (
          <div className={styles.heroStage} key={stage.title}>
            {/* Вступительная анимация только у первой стадии: остальные две
                на момент загрузки за пределами экрана. */}
            <div className={index === 0 ? styles.intro : undefined}>
              <p className={styles.eyebrow}>{stage.eyebrow}</p>

              {index === 0 ? (
                <h1 className={styles.heroTitle}>{splitTitle(stage.title)}</h1>
              ) : (
                <h2 className={styles.heroTitle}>{stage.title}</h2>
              )}

              <div className={styles.heroSubtitle}>
                {stage.lines.map((line) => (
                  <p key={line} className={styles.subtitleLine}>
                    {line}
                  </p>
                ))}
              </div>

              {stage.actions && (
                <div className={styles.heroActions}>
                  {stage.actions.map((action) => (
                    <a
                      key={action.label}
                      href={action.href}
                      className={`btn ${action.variant === 'gold' ? 'btn-gold' : 'btn-ghost'}`}
                      {...(action.external ? { target: '_blank', rel: 'noopener' } : {})}
                    >
                      {action.label}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Component;
