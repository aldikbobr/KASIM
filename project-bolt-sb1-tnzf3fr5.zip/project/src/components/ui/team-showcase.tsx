'use client';

import { useState } from 'react';
import Image from 'next/image';
import { FaInstagram, FaWhatsapp } from 'react-icons/fa';
import { cn } from '@/lib/utils';

export interface TeamMember {
  id: string;
  name: string;
  /** Специализация барбера: «фейд · борода» */
  role: string;
  /** Путь к фото в /public. null → отрисуется заглушка с инициалом */
  image: string | null;
  social?: {
    instagram?: string;
    whatsapp?: string;
  };
}

/**
 * ВРЕМЕННО: в крупной строке стоит специализация, а не имя мастера.
 *
 * Фото сгенерированы (Higgsfield, Z Image) и настоящих барберов не изображают.
 * Подписать такой портрет реальным именем — значит заявить, что клиента
 * подстрижёт именно этот человек. Настоящие имена у нас есть (всплыли в
 * отзывах 2ГИС), и приклеивать к ним выдуманные лица нельзя.
 *
 * Когда появятся реальные фото: поменять `image` на свой файл и `name` на имя
 * мастера, `role` оставить специализацией. Вёрстка не меняется.
 */
const DEFAULT_MEMBERS: TeamMember[] = [
  { id: '1', name: 'Фейд', role: 'классика и чёткий переход', image: '/barbers/01.jpg', social: { whatsapp: 'https://wa.me/77479777080' } },
  { id: '2', name: 'Борода', role: 'опасная бритва, горячее полотенце', image: '/barbers/02.jpg', social: { whatsapp: 'https://wa.me/77788394584' } },
  { id: '3', name: 'Детские', role: 'спокойно и без слёз', image: '/barbers/03.jpg', social: { whatsapp: 'https://wa.me/77079277780' } },
  { id: '4', name: 'Андеркат', role: 'объём и текстура', image: '/barbers/04.jpg', social: { whatsapp: 'https://wa.me/77479777080' } },
  { id: '5', name: 'Камуфляж седины', role: 'естественный тон', image: '/barbers/05.jpg', social: { whatsapp: 'https://wa.me/77788394584' } },
  { id: '6', name: 'Бритьё головы', role: 'гладко, с уходом', image: '/barbers/06.jpg', social: { whatsapp: 'https://wa.me/77079277780' } },
];

interface TeamShowcaseProps {
  members?: TeamMember[];
}

export default function TeamShowcase({ members = DEFAULT_MEMBERS }: TeamShowcaseProps) {
  const [activeId, setActiveId] = useState<string | null>(null);

  const col1 = members.filter((_, i) => i % 3 === 0);
  const col2 = members.filter((_, i) => i % 3 === 1);
  const col3 = members.filter((_, i) => i % 3 === 2);

  return (
    <div className="mx-auto flex w-full max-w-5xl select-none flex-col items-start gap-8 md:flex-row md:gap-10 lg:gap-14">
      {/* ── Слева: сетка фото со смещением колонок ──
          w-full + min-w-0 на мобильном: без них блок раздувается по содержимому
          (три колонки ≈ 505px), overflow-x-auto не срабатывает и ломает всю страницу. */}
      <div className="flex w-full min-w-0 gap-2 overflow-x-auto pb-1 md:w-auto md:flex-shrink-0 md:gap-3 md:pb-0">
        <div className="flex flex-col gap-2 md:gap-3">
          {col1.map((member) => (
            <PhotoCard key={member.id} member={member} activeId={activeId} onActivate={setActiveId}
              className="h-[120px] w-[110px] sm:h-[140px] sm:w-[130px] md:h-[165px] md:w-[155px]" />
          ))}
        </div>
        <div className="mt-[48px] flex flex-col gap-2 sm:mt-[56px] md:mt-[68px] md:gap-3">
          {col2.map((member) => (
            <PhotoCard key={member.id} member={member} activeId={activeId} onActivate={setActiveId}
              className="h-[132px] w-[122px] sm:h-[155px] sm:w-[145px] md:h-[182px] md:w-[172px]" />
          ))}
        </div>
        <div className="mt-[22px] flex flex-col gap-2 sm:mt-[26px] md:mt-[32px] md:gap-3">
          {col3.map((member) => (
            <PhotoCard key={member.id} member={member} activeId={activeId} onActivate={setActiveId}
              className="h-[125px] w-[115px] sm:h-[146px] sm:w-[136px] md:h-[172px] md:w-[162px]" />
          ))}
        </div>
      </div>

      {/* ── Справа: список имён ── */}
      <div className="flex w-full flex-1 flex-col gap-4 sm:grid sm:grid-cols-2 md:flex md:flex-col md:gap-5 md:pt-2">
        {members.map((member) => (
          <MemberRow key={member.id} member={member} activeId={activeId} onActivate={setActiveId} />
        ))}
      </div>
    </div>
  );
}

/* ───────── Карточка фото ───────── */

function PhotoCard({
  member,
  className,
  activeId,
  onActivate,
}: {
  member: TeamMember;
  className: string;
  activeId: string | null;
  onActivate: (id: string | null) => void;
}) {
  const isActive = activeId === member.id;
  const isDimmed = activeId !== null && !isActive;

  return (
    <div
      className={cn(
        'relative flex-shrink-0 overflow-hidden rounded-xl ring-1 transition-all duration-300',
        className,
        isActive ? 'ring-[var(--gold)]' : 'ring-white/10',
        isDimmed ? 'opacity-60' : 'opacity-100',
      )}
      onMouseEnter={() => onActivate(member.id)}
      onMouseLeave={() => onActivate(null)}
      aria-hidden="true"
    >
      {member.image ? (
        <Image
          src={member.image}
          alt=""
          fill
          sizes="172px"
          // Кадр вертикальный, карточка почти квадратная: держим верх,
          // иначе object-cover срезает голову.
          className="object-cover object-[center_18%] transition-[filter] duration-500"
          style={{ filter: isActive ? 'grayscale(0) brightness(1)' : 'grayscale(1) brightness(0.77)' }}
        />
      ) : (
        <Placeholder name={member.name} isActive={isActive} />
      )}
    </div>
  );
}

/** Заглушка вместо фото: инициал на тёмном градиенте */
function Placeholder({ name, isActive }: { name: string; isActive: boolean }) {
  return (
    <div
      className={cn(
        'flex h-full w-full items-center justify-center bg-gradient-to-b from-white/[0.07] to-transparent transition-opacity duration-500',
        isActive ? 'opacity-100' : 'opacity-70',
      )}
    >
      <span className="font-display text-4xl text-[var(--gold)]/40">{name.slice(-1)}</span>
    </div>
  );
}

/* ───────── Строка с именем ───────── */

function MemberRow({
  member,
  activeId,
  onActivate,
}: {
  member: TeamMember;
  activeId: string | null;
  onActivate: (id: string | null) => void;
}) {
  const isActive = activeId === member.id;
  const isDimmed = activeId !== null && !isActive;
  const hasSocial = Boolean(member.social?.instagram ?? member.social?.whatsapp);

  return (
    <div
      className={cn('transition-opacity duration-300', isDimmed ? 'opacity-50' : 'opacity-100')}
      onMouseEnter={() => onActivate(member.id)}
      onMouseLeave={() => onActivate(null)}
      onFocus={() => onActivate(member.id)}
      onBlur={() => onActivate(null)}
    >
      <div className="flex items-center gap-2.5">
        <span
          className={cn(
            'h-3 flex-shrink-0 rounded-[5px] transition-all duration-300',
            isActive ? 'w-5 bg-[var(--gold)]' : 'w-4 bg-foreground/25',
          )}
        />
        <span
          className={cn(
            'font-display text-base leading-none tracking-wide uppercase transition-colors duration-300 md:text-[19px]',
            isActive ? 'text-foreground' : 'text-foreground/80',
          )}
        >
          {member.name}
        </span>

        {hasSocial && (
          <div
            className={cn(
              'ml-0.5 flex items-center gap-1.5 transition-all duration-200',
              isActive ? 'translate-x-0 opacity-100' : '-translate-x-2 opacity-0',
            )}
          >
            {member.social?.instagram && (
              <SocialLink href={member.social.instagram} label={`Instagram — ${member.name}`}>
                <FaInstagram size={12} />
              </SocialLink>
            )}
            {member.social?.whatsapp && (
              <SocialLink href={member.social.whatsapp} label={`WhatsApp — ${member.name}`}>
                <FaWhatsapp size={12} />
              </SocialLink>
            )}
          </div>
        )}
      </div>

      <p className="mt-1.5 pl-[27px] text-[11px] font-medium tracking-[0.2em] text-muted-foreground uppercase md:text-[12px]">
        {member.role}
      </p>
    </div>
  );
}

function SocialLink({ href, label, children }: { href: string; label: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      title={label}
      className="rounded p-1 text-muted-foreground transition-all duration-150 hover:scale-110 hover:bg-foreground/10 hover:text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--gold)]"
    >
      {children}
    </a>
  );
}
